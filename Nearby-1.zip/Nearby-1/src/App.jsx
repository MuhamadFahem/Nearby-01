
import React from 'react';
import { Card, CardContent } from './components/ui/card';
import { MapPin, Star, ShoppingCart } from 'lucide-react';
import { Button } from './components/ui/button';
import './App.css';

export default function App() {
  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card className="rounded-2xl shadow-lg">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Explore Nearby Shops & Properties</h2>
          <img
            src="https://maps.googleapis.com/maps/api/staticmap?center=cairo,egypt&zoom=14&size=600x300&maptype=roadmap&markers=color:red%7Clabel:S%7C30.0444,31.2357"
            alt="Map View"
            className="w-full rounded-xl"
          />
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-lg">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Product Details</h2>
          <p className="text-base font-medium mb-1">Apple AirPods Pro (2nd Gen)</p>
          <p className="text-sm text-muted-foreground">Available at 3 nearby stores</p>
          <div className="flex gap-4 mt-3">
            <Button variant="outline">Compare Prices</Button>
            <Button>Add to Cart</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-lg">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Property Details</h2>
          <p className="font-medium text-base">3-Bedroom Apartment in Zamalek</p>
          <p className="text-sm text-muted-foreground">EGP 12,000/month</p>
          <div className="mt-3 flex justify-between">
            <span className="text-sm">140 sqm | 2 Baths</span>
            <Button variant="secondary">Contact Agent</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="rounded-2xl shadow-lg">
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-2">Ratings & Reviews</h2>
          <p className="text-sm">Store: "Gadget Zone" - 4.7/5 (124 reviews)</p>
          <p className="text-sm">Property: "3BR Zamalek Apt" - 4.9/5 (89 reviews)</p>
        </CardContent>
      </Card>
    </div>
  );
}
